#Udacity Baseball Project

import pandas as pd
import matplotlib.pyplot as plt


df=pd.read_csv('Salaries.csv')
#print df.head()
ave_yearly_sals=df.groupby('yearID').mean()['salary']
#print ave_yearly_sals
plt.scatter(ave_yearly_sals)
plt.show()


"""    
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

"""